# testingSprintBootApplication
Java Sprint Boot application depeloyment on Github Actions on VM using Azure.

- You are given a spring boot application
- Deploy it on Github and perform CI/CD
- Create a web app using Azure
- Connect it to SSHEasy
- Create Dockerfile,image and container on Remote terminal
- Fetch the Github application on Docker container
- Deploy the docker app on Azure.
